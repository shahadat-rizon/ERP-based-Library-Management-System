from odoo import http
from odoo.http import request

class MyController(http.Controller):

    # Route for a simple web page
    @http.route('/library/hello', auth='public', website=True)
    def hello_world(self, **kwargs):
        return "Hello, World from Odoo 18!"

    # Route that returns a template
    @http.route('/library/greet', auth='public', website=True)
    def greet_user(self, **kwargs):
        name = kwargs.get('name', 'Guest')
        return request.render('library_erp.greet_template', {'name': name})

    # JSON route
    @http.route('/library/json_data', auth='public', type='json')
    def json_data(self, **kwargs):
        return {'status': 'success', 'message': 'Hello JSON'}
