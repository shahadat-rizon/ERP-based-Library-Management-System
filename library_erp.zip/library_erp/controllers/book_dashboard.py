from odoo import http
from odoo.http import request

class BookDashboardController(http.Controller):

    @http.route('/library/book_dashboard_data', type='json', auth='user')
    def get_book_dashboard_data(self):
        categories = request.env['library.category'].sudo().search([])
        data = []
        for category in categories:
            books = category.book_ids.read(['title', 'publish_date'])
            data.append({
                'category_name': category.category_name,
                'books': books,
            })
        return data
