from odoo import http
from odoo.http import request

class AdminChart(http.Controller):

    @http.route('/library/book_per_user', type='json', auth='user')
    def get_book_dashboard_data(self):
        user = request.env.user
        if not user.has_group('library_erp.group_library_manager'):
            return {'error': 'Access denied'}

        books = request.env['library.book'].sudo().search([])

        user_counts = {}
        for book in books:
            creator = book.create_uid.name or "Unknown"
            user_counts[creator] = user_counts.get(creator, 0) + 1


        data = [
            {'user_name': name, 'book_count': count}
            for name, count in user_counts.items()
        ]

        return data