/** @odoo-module **/

import { Component, onWillStart, useState , useRef, onMounted} from "@odoo/owl";
import { registry } from "@web/core/registry";
import { standardActionServiceProps } from "@web/webclient/actions/action_service";
import { rpc } from "@web/core/network/rpc";
import {loadJS} from "@web/core/assets"
import { renderBooksBarChart } from "./book_per_category_chart";
import { renderBooksPerUser } from "./books_per_user";

export class BookDashboard extends Component {
    static template = "book.Dashboard";
    static props = { ...standardActionServiceProps };

    setup() {
        this.state = useState({ categories: [], booksPerUser: [] , is_error: false });
        this.chartRef = useRef("chart")
        this.book_per_user_chart = useRef("book_per_user")


        onWillStart(async () => {
            const data = await rpc("/library/book_dashboard_data");
            this.state.categories = data;

            const BooksPerUser = await rpc('/library/book_per_user');

            if (BooksPerUser && BooksPerUser.error){
                this.state.booksPerUser = []
                this.state.is_error = true
            }else{
              this.state.booksPerUser = BooksPerUser
            }
        });

        onMounted(()=>{
            renderBooksBarChart(this.chartRef.el, this.state.categories);
            renderBooksPerUser(this.book_per_user_chart.el, this.state.booksPerUser);
        })
    }


}

registry.category("actions").add("book_dashboard", BookDashboard);
