
export function renderBooksBarChart(canvasEl, categories) {
    if (!canvasEl || !categories?.length) return;

    const labels = categories.map(c => c.category_name);
    const data = categories.map(c => c.books.length);

    new Chart(canvasEl, {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: 'Number of Books per Category',
                    data,
                    borderWidth: 1,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                },
            ],
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                },
            },
        },
    });
}
