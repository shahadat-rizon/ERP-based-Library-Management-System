
import { registry } from "@web/core/registry";
import { SelectionField } from "@web/views/fields/selection/selection_field";
import { xml } from "@odoo/owl";

export class FancyRoleDropdown extends SelectionField {
    static template = xml/* xml */ `
        <div class="dropdown relative">
            <button class="btn btn-outline-primary w-full flex justify-between items-center">
                <t t-esc="displayName"/>
                <i class="fa fa-chevron-down ml-2"></i>
            </button>
            <div t-if="state.open" class="absolute bg-white border shadow-lg mt-1 w-full rounded-lg">
                <t t-foreach="props.selection" t-as="option" t-key="option[0]">
                    <div t-on-click="() => this.onSelect(option[0])"
                         class="p-2 hover:bg-gray-100 cursor-pointer">
                        <t t-esc="option[1]"/>
                    </div>
                </t>
            </div>
        </div>
    `;
}

registry.category("fields").add("fancy_role_dropdown", FancyRoleDropdown);
