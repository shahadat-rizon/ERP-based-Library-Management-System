import { registry } from "@web/core/registry";

function myClientAction(env, action) {
    console.log("My Client Action");
    console.log("env", env)
    console.log("action", action)

    env.services.notification.add("This is client action")
}

registry.category("actions").add("my_client_action", myClientAction);
