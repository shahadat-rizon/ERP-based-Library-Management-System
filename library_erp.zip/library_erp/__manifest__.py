{
    'name': 'Library ERP',
    'version': '1.0',
    'summary': "Managing Library",
    "category": "Education",
    'depends': ['base', 'product', 'sale', 'stock','website_sale'],
    'installable': True,


    "author": "Md Torikul",
    'assets': {
        'web.assets_backend': [
            "https://cdn.jsdelivr.net/npm/chart.js",
            'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js',  # MUST be first
            'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.5.0/chart.min.js',
            'static/src/js/library_access_dropdown.js',
            "library_erp/static/src/actions/*",
            "library_erp/static/src/components/**/*",
        ],
    },

    'data': [
        "security/library_groups.xml",
        "security/ir.model.access.csv",
        "views/product_template.xml",
        "views/report/report_sale_order.xml",
        "views/report/report_action.xml",
        "views/author.xml",
        "views/book.xml",
        "views/category.xml",
        "views/borrow.xml",
        "views/book_inherit.xml",
        "views/invoice_view.xml",
        "views/quotations.xml",
        "views/account_move_inherit_view.xml",
        "views/account_move_line_inherit_view.xml",
        "views/sale_order.xml",
        "views/menus.xml",
        "views/library/greet.xml",
        "views\E-Commerce_Inherit\custom_card_view.xml",
    ],
    'application': True,
    'license': 'LGPL-3',
}
