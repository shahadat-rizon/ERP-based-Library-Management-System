from odoo import models, fields

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    x_book_reference = fields.Many2one(
        'library.book',
        string="Book Reference",
        help="The book linked to this invoice line"
    )
