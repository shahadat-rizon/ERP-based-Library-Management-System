from odoo import models, fields

class Borrow(models.Model):
    _name = "library.borrow"
    _description = "This is borrow table"
    _rec_name = "borrowed_by"

    book_id = fields.Many2one("library.book", string="Book ID", required=True)
    borrow_id = fields.Char(string="Borrow Id", required=True)
    borrowed_by = fields.Char(string="Borrowed By", required=True)
    borrow_date = fields.Date(string="Borrow Date", required=True)

