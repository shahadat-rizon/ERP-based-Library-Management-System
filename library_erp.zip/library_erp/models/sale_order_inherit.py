from odoo import models, fields, api
 


# class SaleOrderInherit(models.Model):
#     _inherit = "sale.order"
#     product_info = fields.Text(string="Product Info", readonly=True)



class SaleOrderLineInherit(models.Model):
    _inherit = "sale.order.line"
    additional_info = fields.Char(string="Additional Info", help="Link to the related sale order for additional information.")

    def _prepare_invoice_line(self, **optional_values):
        res = super()._prepare_invoice_line(**optional_values)
        res.update({
            'additional_info': self.additional_info,
        })
        return res

    def write(self, values):
        res = super().write(values)

        # If additional_info changed, push update to related stock moves
        if 'additional_info' in values:
            for line in self:
                stock_moves = self.env['stock.move'].search([('sale_line_id', '=', line.id)])
                stock_moves.write({'additional_info': line.additional_info})
                print(f"Updated {len(stock_moves)} stock moves from sale line {line.id}")

        return res


class InvoiceDraftInherit(models.Model):
    _inherit = "account.move.line"
    additional_info = fields.Char(string="Additional Info", help="Link to the related sale order for additional information.")


# class StockPickingInherit(models.Model):
#     _inherit = "stock.picking"
#     additional_info = fields.Char(string="Additional Info", help="Link to the related sale order for additional information.")
    

class StockMoveInherit(models.Model):
    _inherit = "stock.move"
    additional_info = fields.Char(string="Additional", help="Link to the related sale order for additional information.")

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('sale_line_id'):
                 sale_order_line = self.env["sale.order.line"].browse(vals.get('sale_line_id'))
                 vals["additional_info"] = sale_order_line.additional_info
        return super().create(vals_list)







