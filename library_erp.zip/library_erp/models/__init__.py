from . import author
from . import book
from . import borrow
from . import book_inherit
from . import account_move_inherit
from .  import account_move_line_inherit
from . import sale_order_inherit
from . import category


