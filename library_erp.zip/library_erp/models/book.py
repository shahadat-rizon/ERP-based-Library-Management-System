from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import uuid
from datetime import date


class Book(models.Model):
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _name = "library.book"
    _description = "This is the book table"
    _rec_name = "title"

    book_id = fields.Char(
        string="Book Id",
        required=True,
        readonly=True,
        default=lambda self: str(uuid.uuid4()),
        help="Unique Identifier for the Book"
    )
    title = fields.Char(string="Title", required=True)
    publish_date = fields.Date(string="Publish Date")
    author_id = fields.Many2one("library.author", string="Author")
    category_id = fields.Many2one("library.category", string="Category Id")
    product_id = fields.Many2one('product.template', string="Related Product", ondelete="set null")

    quality = fields.Selection([
        ('affordable', 'Affordable'),
        ('premium', 'Premium')
    ], string="Quality")

    price = fields.Float(string="Price", compute="_compute_price", store=True, readonly=True)

    page_quality_ids = fields.One2many(
        'library.book.page_quality',
        'book_id',
        string="Page Qualities"
    )

    is_borrowed = fields.Boolean(
        string="Is Borrowed",
        compute="_compute_is_borrowed",
        store=True
    )
    borrow_ids = fields.One2many('library.borrow', 'book_id', string="Borrow Records", ondelete="cascade")

    @api.depends('quality', 'page_quality_ids')
    def _compute_price(self):
        for book in self:
            if book.quality:
                price_record = book.page_quality_ids.filtered(lambda r: r.quality == book.quality)
                book.price = price_record.price if price_record else 0

    @api.depends('borrow_ids')
    def _compute_is_borrowed(self):
        for book in self:
            book.is_borrowed = bool(book.borrow_ids)

    @api.constrains('publish_date')
    def _check_publish_date(self):
        for record in self:
            if record.publish_date and record.publish_date > date.today():
                raise ValidationError("Publish date cannot be in the future.")

    def action_create_product(self):
        for book in self:
            if not book.product_id:
                product = self.env['product.template'].create({
                    'name': book.title,
                    'list_price': 10.0,
                    'sale_ok': True,
                    'purchase_ok': True,
                })
                book.product_id = product.id

    def action_create_sale_order(self):
        SaleOrder = self.env['sale.order']
        for book in self:
            if not book.product_id:
                raise ValidationError("Please create a product for the book first.")
            sale_order = SaleOrder.create({
                'partner_id': self.env.user.partner_id.id,
                'order_line': [(0, 0, {
                    'product_id': book.product_id.id,
                    'product_uom_qty': 1,
                    'price_unit': book.product_id.list_price,
                })],
            })
            return {
                'name': 'Sale Order',
                'type': 'ir.actions.act_window',
                'res_model': 'sale.order',
                'view_mode': 'form',
                'res_id': sale_order.id,
                'target': 'current',
            }


class BookPageQuality(models.Model):
    _name = "library.book.page_quality"
    _description = "Book Page Quality"

    book_id = fields.Many2one('library.book', string="Book", ondelete="cascade")
    quality = fields.Selection([
        ('affordable', 'Affordable'),
        ('premium', 'Premium')
    ], string="Page Quality", required=True)
    price = fields.Float(string="Price", required=True)



# from odoo import models, fields, api
# from odoo.exceptions import ValidationError
# import uuid
# from datetime import date
#
#
# class Book(models.Model):
#     _inherit = ['mail.thread', 'mail.activity.mixin']
#     _name = "library.book"
#     _description = "This is the book table"
#     _rec_name = "title"
#
#     book_id = fields.Char(string="Book Id", required=True, unique=True,
#                           readonly=True, default=lambda self: str(uuid.uuid4()), help="Unique Identifier for the Book")
#     title = fields.Char(string="Title", required=True)
#     publish_date = fields.Date(string="Publish Date")
#     author_id = fields.Many2one("library.author", string="Author")
#     category_id = fields.Many2one("library.category", string="Category Id")
#     # Link to product template
#     product_id = fields.Many2one('product.template', string="Related Product", ondelete="set null")
#
#     is_borrowed = fields.Boolean(
#         string="Is Borrowed",
#         compute="_compute_is_borrowed",
#         store=True
#     )
#     borrow_ids = fields.One2many('library.borrow', 'book_id', string="Borrow Records", ondelete="cascade")
#
#     def action_my_client_action(self):
#         return {
#             "type": "ir.actions.client",
#             "tag": "my_client_action",
#             "context": {
#                 "default_name": "Library management"
#             }
#         }
#     def find_books_by_t_author(self):
#         authors = self.env['library.author'].search[('name', '=ilike', 't%')]
#         books = self.env['library.book'].search([('author_id', 'in', authors.ids)])
#
#         return {
#             'type': 'ir.actions.act_window',
#             'name': 'Books by T Authors',
#             'res_model': 'library.book',
#             'view_mode': 'tree,form',
#             'domain': [('id', 'in', books.ids)],
#             'target': 'current',
#
#         }
#
#     @api.depends('borrow_ids')
#     def _compute_is_borrowed(self):
#         for book in self:
#             book.is_borrowed =  bool(book.borrow_ids)
#
#
#     @api.constrains('publish_date')
#     def _check_publish_date(self):
#         for record in self:
#             if record.publish_date and record.publish_date > date.today():
#                 raise ValidationError("Publish date cannot be in the future.")
#
#
#
#     def action_create_product(self):
#         """Create a product record for the book."""
#         for book in self:
#             if not book.product_id:
#                 product = self.env['product.template'].create({
#                     'name': book.title,
#                     #'type': 'storable',  # Corrected to 'storable'
#                     'list_price': 10.0,
#                     'sale_ok': True,
#                     'purchase_ok': True,
#                 })
#                 book.product_id = product.id
#
#
#     # Make sale order
#     def action_create_sale_order(self):
#         """Create a sale order for the book."""
#         SaleOrder = self.env['sale.order']
#         SaleOrderLine = self.env['sale.order.line']
#         for book in self:
#             if not book.product_id:
#                 raise ValidationError("Please create a product for the book first.")
#             sale_order = SaleOrder.create({
#                 'partner_id': self.env.user.partner_id.id,
#                 'order_line': [(0, 0, {
#                     'product_id': book.product_id.id,
#                     'product_uom_qty': 1,
#                     'price_unit': book.product_id.list_price,
#                 })],
#             })
#             return {
#                 'name': 'Sale Order',
#                 'type': 'ir.actions.act_window',
#                 'res_model': 'sale.order',
#                 'view_mode': 'form',
#                 'res_id': sale_order.id,
#                 'target': 'current',
#             }

# class LibraryBook(models.Model):
#     _name = "library.book"
#     _inherits = {"product.template": "product_tmpl_id"}
#     _description = "Book that is also a Product"

#     product_tmpl_id = fields.Many2one("product.template", required=True, ondelete="cascade")
#     author_id = fields.Many2one("library.author", string="Author")