from odoo import models, fields, api 
import logging
_logger = logging.getLogger(__name__)

class BookInherit(models.Model):
    _inherit = "library.book"

    isbn = fields.Char(string="ISBN", help="International Standard Book Number")
    pages = fields.Integer(string="Number of Pages", help="Total number of pages in the book")
    language = fields.Selection([
        ('en', 'English'),
        ('fr', 'French'),
        ('de', 'German'),
        ('es', 'Spanish'),
        ('other', 'Other')
    ], string="Language", default='en', help="Language of the book")


    #------------------------------------    Extending the create product method 
    # def action_create_product(self):
    #     res = super().action_create_product()

    #     for book in self:
    #         if book.product_id:
    #             _logger.info("Creating product for book: %s", book.title)
    #             book.message_post(body=f"Creating product for book: {book.title}")
        
    #     return res 

    #------------------------------------          Overriding create method completely
    def action_create_product(self):
        """Create a product record for the book with extended details."""
        for book in self:
            if not book.product_id:
                _logger.info("Creating product for book: %s", book.title)
                product = self.env['product.template'].create({
                    'name': book.title,
                    #'type': 'storable',  # Corrected to 'storable'
                    'list_price': 300.0,
                    'sale_ok': True,
                    'purchase_ok': True,
                    'description_sale': f"ISBN: {book.isbn}\nPages: {book.pages}\nLanguage: {book.language}",
                })
                book.product_id = product.id
                book.message_post(body=f"Product created for book: {book.title} with ISBN: {book.isbn}, Pages: {book.pages}, Language: {book.language}")
    
