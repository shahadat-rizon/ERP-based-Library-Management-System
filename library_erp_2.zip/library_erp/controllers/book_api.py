from odoo import http
from odoo.http import request
import json

class BookAPIController(http.Controller):

    @http.route('/api/library/create_book', type='json', auth='none', csrf=False, methods=['POST'])
    def create_book(self, **kwargs):
        # Get JSON data correctly in Odoo 18
        data = request.get_json_data()

        title = data.get('title')
        publish_date = data.get('publish_date')
        author_id = data.get('author_id')
        category_id = data.get('category_id')

        if not title:
            return {"status": "error", "message": "Title is required"}

        book = request.env['library.book'].sudo().create({
            'title': title,
            'publish_date': publish_date,
            'author_id': author_id,
            'category_id': category_id,
        })

        return {
            "status": "success",
            "message": "Book created successfully",
            "book_id": book.id
        }


class BookController(http.Controller):
    class BookController(http.Controller):

        @http.route('/api/book/<int:book_id>', auth='public', type='json', methods=['GET'], csrf=False)
        def get_book(self, book_id, **kwargs):
            Book = request.env['library.book'].sudo()
            book = Book.browse(book_id)

            if not book.exists():
                return {'error': 'Book not found'}

            return {
                'id': book.id,
                'book_uuid': book.book_id,
                'title': book.title,
                'publish_date': str(book.publish_date) if book.publish_date else None,
                'quality': book.quality,
                'price': book.quality_price,

                'author': {
                    'id': book.author_id.id if book.author_id else None,
                    'name': book.author_id.name if book.author_id else None,
                    'age': book.author_id.age if book.author_id else None,
                    'total_books': book.author_id.total_books if book.author_id else None,
                },

                'category': {
                    'id': book.category_id.id if book.category_id else None,
                    'name': book.category_id.category_name if book.category_id else None,
                },

                'product': {
                    'id': book.product_id.id if book.product_id else None,
                    'name': book.product_id.name if book.product_id else None,
                }
            }

    class BookDeleteController(http.Controller):

        @http.route('/api/library/delete_book', type='json', auth='public', methods=['POST'], csrf=False)
        def delete_book(self, **kwargs):
            """
            Delete a book by its ID.
            Expected JSON body:
            {
                "book_id": 1
            }
            """
            data = request.get_json_data()
            if not data:
                return {"status": "error", "message": "No JSON data provided"}

            book_id = data.get("book_id")
            if not book_id:
                return {"status": "error", "message": "'book_id' is required"}

            book = request.env['library.book'].sudo().browse(book_id)
            if not book.exists():
                return {"status": "error", "message": f"Book with ID {book_id} not found"}

            try:
                book.unlink()
                return {"status": "success", "message": f"Book with ID {book_id} deleted successfully"}
            except ValidationError as e:
                return {"status": "error", "message": str(e)}
            except Exception as e:
                return {"status": "error", "message": f"Unexpected error: {str(e)}"}

    class BookQualityController(http.Controller):

        @http.route('/api/get_price', type='json', auth='public', methods=['GET'], csrf=False)
        def get_price(self, **kwargs):
            book_id = kwargs.get('book_id')
            quality = kwargs.get('quality')

            if not book_id or not quality:
                return {
                    "success": False,
                    "message": "book_id and quality are required"
                }

            Book = request.env['library.book'].sudo()
            book = Book.search([('id', '=', book_id)], limit=1)

            if not book:
                return {
                    "success": False,
                    "message": "Book not found"
                }

            # Use the book's stored quality_price
            price = book.quality_price

            return {
                "success": True,
                "book_id": book.id,
                "quality": quality,
                "price": price
            }

    # class BookController(http.Controller):
    #
    #     @http.route('/api/book/<int:book_id>', auth='public', type='json', methods=['GET'], csrf=False)
    #     def get_book_info(self, book_id, **kwargs):
    #         # Search for the book
    #         book = request.env['library.book'].sudo().search([('id', '=', book_id)], limit=1)
    #         if not book:
    #             return {"success": False, "message": "Book not found"}
    #
    #         # Prepare book data with nested author
    #         book_data = {
    #             "id": book.id,
    #             "book_id": book.book_id,
    #             "title": book.title,
    #             "publish_date": str(book.publish_date) if book.publish_date else False,
    #             "quality": book.quality,
    #             "price": book.quality_price,
    #             "is_borrowed": book.is_borrowed,
    #             "author": {
    #                 "id": book.author_id.id,
    #                 "name": book.author_id.name,
    #                 "age": book.author_id.age,
    #                 "total_books": book.author_id.total_books
    #             } if book.author_id else None,
    #             "category": {
    #                 "id": book.category_id.id,
    #                 "name": book.category_id.name
    #             } if book.category_id else None
    #         }
    #
    #         return {"success": True, "book": book_data}

# class BookController(http.Controller):
#
#     @http.route('/api/book/<int:book_id>', type='json', auth='public', methods=['GET'], csrf=False)
#     def get_book(self, book_id, **kwargs):
#         book = request.env['book.book'].sudo().browse(book_id)
#
#         if not book.exists():
#             return {"success": False, "message": "Book not found"}
#
#         return {
#             "success": True,
#             "data": {
#                 "id": book.id,
#                 "name": book.name,
#                 "author": book.author,
#                 "price": book.price,
#                 "description": book.description,
#             }
#         }
