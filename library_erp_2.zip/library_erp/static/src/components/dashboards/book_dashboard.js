/** @odoo-module **/

import { Component, onWillStart, useState, useRef, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { standardActionServiceProps } from "@web/webclient/actions/action_service";
import { rpc } from "@web/core/network/rpc";
import { renderBooksBarChart } from "./book_per_category_chart";
import { renderBooksPerUser } from "./books_per_user";

export class BookDashboard extends Component {
    static template = "book.Dashboard";
    static props = { ...standardActionServiceProps };

    setup() {
        this.state = useState({
            categories: [],
            booksPerUser: [],
            districts: [],
            division: [],          // FIXED: must exist, initialized as empty array
            isLoading: false,
            error: null,
            is_error: false,
        });

        this.chartRef = useRef("chart");
        this.book_per_user_chart = useRef("book_per_user");

        onWillStart(async () => {
            const data = await rpc("/library/book_dashboard_data");
            this.state.categories = data;

            const BooksPerUser = await rpc("/library/book_per_user");

            if (BooksPerUser && BooksPerUser.error) {
                this.state.booksPerUser = [];
                this.state.is_error = true;
            } else {
                this.state.booksPerUser = BooksPerUser;
            }
        });

        onMounted(() => {
            renderBooksBarChart(this.chartRef.el, this.state.categories);
            renderBooksPerUser(this.book_per_user_chart.el, this.state.booksPerUser);
        });
    }

    async loadDivision() {
        this.state.isLoading = true;
        this.state.error = null;

        try {
            const response = await fetch("https://bdapis.com/api/v1.2/divisions");

            if (!response.ok) {
                throw new Error("API returned status " + response.status);
            }

            const json = await response.json();
            console.log(json.data);

            this.state.division = json.data || [];  // FIXED
        } catch (error) {
            console.error("Failed to load divisions:", error);
            this.state.error = "Could not load divisions. Check network or API.";
            this.state.division = [];  // FIXED: must exist
        }

        this.state.isLoading = false;
    }

    async loadDistrics() {
        this.state.isLoading = true;
        this.state.error = null;

        try {
            const response = await fetch("https://bdapis.com/api/v1.2/districts");

            if (!response.ok) {
                throw new Error("API returned status " + response.status);
            }

            const json = await response.json();
            console.log(json.data);

            this.state.districts = json.data || [];  // FIXED
        } catch (error) {
            console.error("Failed to load districts:", error);
            this.state.error = "Could not load districts. Check network or API.";
            this.state.districts = [];  // FIXED: must exist
        }

        this.state.isLoading = false;
    }
}

registry.category("actions").add("book_dashboard", BookDashboard);


// /** @odoo-module **/
//
// import { Component, onWillStart, useState , useRef, onMounted} from "@odoo/owl";
// import { registry } from "@web/core/registry";
// import { standardActionServiceProps } from "@web/webclient/actions/action_service";
// import { rpc } from "@web/core/network/rpc";
// import { renderBooksBarChart } from "./book_per_category_chart";
// import { renderBooksPerUser } from "./books_per_user";
//
// export class BookDashboard extends Component {
//     static template = "book.Dashboard";
//     static props = { ...standardActionServiceProps };
//
//     setup() {
//         this.state = useState({
//             categories: [],
//             booksPerUser: [],
//             districts: [],         // State for loaded divisions
//             isLoading: false,      // NEW: State for loading indicator
//             error: null,           // NEW: State for error message
//             is_error: false
//         });
//
//         this.chartRef = useRef("chart")
//         this.book_per_user_chart = useRef("book_per_user")
//
//         onWillStart(async () => {
//             const data = await rpc("/library/book_dashboard_data");
//             this.state.categories = data;
//
//             const BooksPerUser = await rpc('/library/book_per_user');
//
//             if (BooksPerUser && BooksPerUser.error){
//                 this.state.booksPerUser = []
//                 this.state.is_error = true
//             }else{
//               this.state.booksPerUser = BooksPerUser
//             }
//         });
//
//         onMounted(()=> {
//             renderBooksBarChart(this.chartRef.el, this.state.categories);
//             renderBooksPerUser(this.book_per_user_chart.el, this.state.booksPerUser);
//         });
//     }
//
//     async loadDivision() {
//         this.state.isLoading = true; // Start loading
//         this.state.error = null;     // Clear previous errors
//
//         try {
//             const response = await fetch("https://bdapis.com/api/v1.2/divisions");
//
//             if (!response.ok) {
//                  throw new Error(`API returned status ${response.status}`);
//             }
//
//             const json = await response.json();
//             console.log(json.data);
//
//             // This line triggers the re-render of the template
//             this.state.division = json.data;
//
//
//         } catch (error) {
//             console.error("Failed to load districts:", error);
//             this.state.error = "Could not load divisions. Check network or API.";
//             this.state.division = [];
//         } finally {
//             this.state.isLoading = false; // Stop loading, regardless of success or failure
//         }
//     }
// }
//
// registry.category("actions").add("book_dashboard", BookDashboard);

// /** @odoo-module **/
//
// import { Component, onWillStart, useState , useRef, onMounted} from "@odoo/owl";
// import { registry } from "@web/core/registry";
// import { standardActionServiceProps } from "@web/webclient/actions/action_service";
// import { rpc } from "@web/core/network/rpc";
// import { renderBooksBarChart } from "./book_per_category_chart";
// import { renderBooksPerUser } from "./books_per_user";
//
// export class BookDashboard extends Component {
//     static template = "book.Dashboard";
//     static props = { ...standardActionServiceProps };
//
//     setup() {
//         this.state = useState({
//             categories: [],
//             booksPerUser: [],
//             districts: [],         // NEW
//             is_error: false
//         });
//
//         this.chartRef = useRef("chart")
//         this.book_per_user_chart = useRef("book_per_user")
//
//         onWillStart(async () => {
//             const data = await rpc("/library/book_dashboard_data");
//             this.state.categories = data;
//
//             const BooksPerUser = await rpc('/library/book_per_user');
//
//             if (BooksPerUser && BooksPerUser.error){
//                 this.state.booksPerUser = []
//                 this.state.is_error = true
//             }else{
//               this.state.booksPerUser = BooksPerUser
//             }
//         });
//
//         onMounted(()=> {
//             renderBooksBarChart(this.chartRef.el, this.state.categories);
//             renderBooksPerUser(this.book_per_user_chart.el, this.state.booksPerUser);
//         });
//     }
//
//     async loadDistricts() {
//         this.state.isLoading = true; // Start loading
//         this.state.error = null;     // Clear previous errors
//
//         try {
//             const response = await fetch("https://bdapis.com/api/v1.2/divisions");
//
//             if (!response.ok) {
//                  throw new Error(`API returned status ${response.status}`);
//             }
//
//             const json = await response.json();
//             console.log(json.data);
//
//             // This line triggers the re-render of the template
//             this.state.districts = json.data;
//
//         } catch (error) {
//             console.error("Failed to load districts:", error);
//             this.state.error = "Could not load divisions. Check network or API.";
//             this.state.districts = [];
//         } finally {
//             this.state.isLoading = false; // Stop loading, regardless of success or failure
//         }
//     }
//
//     async loadDistricts() {
//         try {
//             const response = await fetch("https://bdapis.com/api/v1.2/divisions");
//             const json = await response.json();
//             console.log(json.data); // You will see the array in console
//             this.state.districts = json.data; // Assign the array to reactive state
//         } catch (error) {
//             console.error("Failed to load districts:", error);
//             this.state.districts = [];
//         }
//     }
//
//
//     async loadDistricts() {
//         const response = await fetch("https://bdapis.com/api/v1.2/divisions");
//         const json = await response.json();
//         console.log(json);
//         this.state.districts = json.data;
//     }
// }
//
// registry.category("actions").add("book_dashboard", BookDashboard);


// /** @odoo-module **/
//
// import { Component, onWillStart, useState , useRef, onMounted} from "@odoo/owl";
// import { registry } from "@web/core/registry";
// import { standardActionServiceProps } from "@web/webclient/actions/action_service";
// import { rpc } from "@web/core/network/rpc";
// import {loadJS} from "@web/core/assets"
// import { renderBooksBarChart } from "./book_per_category_chart";
// import { renderBooksPerUser } from "./books_per_user";
//
// export class BookDashboard extends Component {
//     static template = "book.Dashboard";
//     static props = { ...standardActionServiceProps };
//
//     setup() {
//         this.state = useState({ categories: [], booksPerUser: [] , is_error: false });
//         this.chartRef = useRef("chart")
//         this.book_per_user_chart = useRef("book_per_user")
//
//
//         onWillStart(async () => {
//             const data = await rpc("/library/book_dashboard_data");
//             this.state.categories = data;
//
//             const BooksPerUser = await rpc('/library/book_per_user');
//
//             if (BooksPerUser && BooksPerUser.error){
//                 this.state.booksPerUser = []
//                 this.state.is_error = true
//             }else{
//               this.state.booksPerUser = BooksPerUser
//             }
//         });
//
//         onMounted(()=>{
//             renderBooksBarChart(this.chartRef.el, this.state.categories);
//             renderBooksPerUser(this.book_per_user_chart.el, this.state.booksPerUser);
//         })
//     }
//
//
// }
//
// registry.category("actions").add("book_dashboard", BookDashboard);
