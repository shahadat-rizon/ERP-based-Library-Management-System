
export function renderBooksPerUser(canvasEl, books) {
    if (!canvasEl || !books?.length) return;

     const labels =  books.map(c => c.user_name);
     const data =  books.map(c => c.book_count);

    new Chart(canvasEl, {
        type: 'bar',
        data: {
            labels,
            datasets: [
                {
                    label: 'Number of Books per User',
                    data,
                    borderWidth: 1,
                    backgroundColor: 'rgba(54, 162, 235, 0.6)',
                },
            ],
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                },
            },
        },
    });
}
