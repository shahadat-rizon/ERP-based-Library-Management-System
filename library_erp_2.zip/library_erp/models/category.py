from odoo import models, fields, api
from odoo.exceptions import ValidationError


class Category(models.Model):
    _name = "library.category"
    _description = "This is the book category"
    _rec_name = "category_name"

    category_name = fields.Char( string="Category Name", required=True)
    book_ids =  fields.One2many("library.book", "category_id", string="Books", ondelete="cascade")
