from odoo import models, fields


class AccountMoveInherit(models.Model):
    _inherit = "account.move"

    x_library_book_id = fields.Many2one("library.book", string="Book", help="Link to the associated book")