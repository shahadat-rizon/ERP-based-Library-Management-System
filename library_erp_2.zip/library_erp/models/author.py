from odoo import models, fields, api

class Author(models.Model):
    _name = "library.author"
    _description = "This is a table about authors"

    name = fields.Char(string="Author Name", required=True)
    age = fields.Integer(string="Author Age", required=True)
    book_ids = fields.One2many("library.book", "author_id", string="Books")
    total_books = fields.Integer(compute="_compute_total_books", string="Total Books")

    @api.depends("book_ids")
    def _compute_total_books(self):
        for record in self:
            record.total_books = len(record.book_ids)
